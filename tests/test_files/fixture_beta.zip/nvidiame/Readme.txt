================================================================================
NVIDIA Display Driver for Windows 9x            version 4.12.01.0631, 09/20/2000
================================================================================

Operating systems supported
---------------------------
Microsoft Windows 95
Microsoft Windows 98
Windows Me

Adapters supported
------------------
NVIDIA RIVA TNT
NVIDIA RIVA TNT2
NVIDIA RIVA TNT2 Pro
NVIDIA RIVA TNT2 Ultra
NVIDIA Vanta
NVIDIA Vanta LT
NVIDIA RIVA TNT2 Model 64
NVIDIA RIVA TNT2 Model 64 Pro
NVIDIA Aladdin TNT2
NVIDIA GeForce 256
NVIDIA GeForce DDR
NVIDIA Quadro
NVIDIA GeForce2 MX
NVIDIA Quadro2 MXR
NVIDIA GeForce2 GTS
NVIDIA GeForce2 Pro
NVIDIA GeForce2 Ultra
NVIDIA Quadro2 Pro


File list
---------
AGP168E.EXE  - AGP support file for Aladdin TNT2
NVAGP.INF    - Windows 9x display driver information file for NVIDIA
               adapters
NVARCH16.DLL - NVIDIA interface layer to NV architecture for 16-bit clients
NVARCH32.DLL - NVIDIA interface layer to NV architecture for 32-bit clients
NVCORE.VXD   - NVIDIA Resource Manager kernel
NVDD32.DLL   - NVIDIA DirectDraw driver
NVDESK32.DLL - NVIDIA desktop manager
NVDISP.DRV   - NVIDIA display driver
NVOPENGL.DLL - NVIDIA OpenGL driver
NVMINI.VXD   - NVIDIA mini-VDD for VGA virtualization and device Plug-N-Play
NVMINI2.VXD  - NVIDIA mini-VDD for device Plug-N-Play of secondary devices
NVCPL.DLL    - NVIDIA display properties extension
NVCPL.HLP    - NVIDIA display properties extension help file
NVQTWK.DLL   - NVIDIA taskbar applet
NVDESK32.DLL - NVIDIA desktop manager
NVDMCPL.DLL  - NVIDIA desktop manager hook library
README.TXT   - The file you're reading.
VGARTD.VXD   - Windows 95 AGP support file

Installation instructions
-------------------------
Windows 95
----------

To prepare for installation of the drivers

1 Start Microsoft Windows 95.

2 Click the Start button, point to Settings, and click Control Panel.

3 Double-click Display, and click the Settings tab.

4 Click Advanced Properties, click the Adapter tab, then click Change.

5 Select Show all devices.

6 Select the Standard display types from the Manufacturers list.

7 Select Standard PCI Graphics Adapter (VGA) from the list, then select OK.

8 Click Apply, click OK, then click Apply.

9 Click Yes when Windows asks if you wish to restart the computer.  



To install the drivers

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Display, and click the Settings tab.

3 Click Advanced Properties, click the Adapter tab, then click Change.

4 Select Have Disk, then select or type the path to the driver files, then click
  OK.

  Windows should find files for your NVIDIA graphics chip.  If Windows cannot 
  find the files, check that the path name for the diskette is correct and 
  that the correct diskette is inserted in it. 

5 If Windows found the files, select OK.

  Windows copies the files to the hard disk.  

6 Click Apply, click OK, then click Apply.

7 Click Yes when Windows asks if you wish to restart the computer.  




Windows 98
----------

To prepare for installation of the drivers

1 Start Microsoft Windows 98.

2 Click the Start button, point to Settings, and click Control Panel.

3 Double-click Display, and click the Settings tab.

4 Click Advanced, click the Adapter tab, then click Change.

5 Click Next, click Display a list of all the drivers in a specific location, so
  you can select the driver you want, then click Next.

6 Select Show all Hardware button, then select the Standard display types from
  the Manufacturers list.

7 Select Standard PCI Graphics Adapter (VGA) from the list, then select Next.

8 Click Next to install the driver, then click Finish. 

9 Click Apply, then click Close.

10 Click Yes when Windows asks if you wish to restart the computer.  



To install the drivers

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Display, and click the Settings tab.

3 Click Advanced, click the Adapter tab, then click Change.

4 Click Next, click Display a list of all the drivers in a specific location, so
  you can select the driver you want, then click Next.

5 Click Have Disk, select or type the path to the folder containing the driver
  files, then click OK.

  Windows should find files for your NVIDIA graphics chip.  If Windows cannot 
  find the files, check that the path name for the driver files is correct.

6 If Windows found the files, click OK, then click Next.

  Windows copies the files to the hard disk.  

7 Click Finish, click Apply, then click Close.

8 Click Yes when Windows asks if you wish to restart the computer.  


Uninstall instructions
----------------------

To uninstall the drivers

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Add/Remove Programs, select NVIDIA Display Properties Extension,
  then click Add/Remove.
  
3 You are then asked about being sure if you want to remove the drivers.  Click Yes.

4 You are then asked about restarting the system. Click Yes.



Control Freak 
-------------

To access Control Freak, NVIDIA's Control Panel applet

1 Click the Start button, point to Settings, and click Control Panel.

2 Double-click Display, and click the tab for your NVIDIA graphics chip.

3 Right click on each option to display information about each setting.


Tips for Users
--------------


Known Issues
------------


Revision history
----------------


================================================================================
Copyright 1999-2000, NVIDIA Corporation.                    All rights reserved.
Document number: DR-00008-001
================================================================================

