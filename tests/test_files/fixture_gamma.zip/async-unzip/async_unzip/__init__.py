"""Version definition to track changes"""
__version__ = "0.2.0"
