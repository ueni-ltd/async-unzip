from pathlib import PurePath, Path
from zipfile import ZipFile, is_zipfile, BadZipFile
from zlib import decompressobj
from aiofile import async_open

DEFAULT_READ_BUFFER_SIZE = 512 * 1024


async def unzip(zip_file, path=None, files=[], regex_files=None, buffer_size=None, ):
    read_block = buffer_size if (buffer_size and int(buffer_size)>0) else DEFAULT_READ_BUFFER_SIZE

    if is_zipfile(zip_file):
        files_info = ZipFile(zip_file).infolist()
        if path == None:
            extra_path = ''
        else:
            extra_path = PurePath(path)
        async with async_open(zip_file, 'rb+') as src:
            for in_file in files_info:
                file_name = in_file.filename
                # print(dir(in_file))
                # continue
                unpack_filename_path = Path(str(PurePath(extra_path, file_name)))

                src.seek(in_file.header_offset)

                await src.read(30)
                await src.read(len(in_file.filename))
                if len(in_file.extra) > 0:
                    await src.read(len(in_file.extra))
                if len(in_file.comment) > 0:
                    await src.read(len(in_file.comment))

                if in_file.is_dir():
                    unpack_filename_path.mkdir(parents=True, exist_ok=True)
                    continue
                else:
                    unpack_filename_path.parent.mkdir(parents=True, exist_ok=True)


                async with async_open(str(unpack_filename_path), 'wb+') as out:

                    decomp = decompressobj(-15)
                    i = in_file.compress_size
                    # print(in_file, i)
                    # continue
                    while i > 0:
                        curr_read_block = read_block if i > read_block else i
                        if curr_read_block == 0:
                            break
                        result = decomp.decompress(await src.read(curr_read_block))
                        await out.write(result)
                        i -= curr_read_block
                    result = decomp.flush()
                    await out.write(result)
    else:
        raise BadZipFile
