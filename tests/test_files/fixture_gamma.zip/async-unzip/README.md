# async-unzip
Asynchronous unzipping of big files with low memory usage in Python
